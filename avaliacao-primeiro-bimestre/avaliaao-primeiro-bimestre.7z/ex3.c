#include <stdio.h>
int main(void){
     int x,y,z=1;
     x=10;
     x+=2;
     y=x;
     z*=x;
     y--;
     printf("x: %d, y: %d, z: %d",x,y,z);
     
}
